package image;

// image importation
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
// error handling
import java.io.IOException;
// used for image treatment
import java.util.HashMap;

public class Image {

    // =============================================================
    //                      CLASS CONSTRUCTOR
    // =============================================================

    /**
     * Creates a byte array of an image from an ARGB file
     * @param imagePath path to the file
     */
    public Image(String imagePath) {

        // the image in buffered form
        BufferedImage bImg = null;

        try {
            // tries and get the image
            bImg = ImageIO.read(new File(imagePath));
        } catch (IOException e) {
            // if the path to the image is halts the program
            System.out.printf("Invalid image path: %s", imagePath);
            System.exit(0);
        }

        // saves the dimensions of the image
        IMAGE_HEIGHT = bImg.getHeight();
        IMAGE_WIDTH = bImg.getWidth();
        IMAGE_HEIGHT_RANGE = IMAGE_HEIGHT - 1;
        IMAGE_WIDTH_RANGE = IMAGE_WIDTH - 1;
        BYTES_PER_ROW = (int) Math.ceil((double) IMAGE_WIDTH / 8);

        // determines the starting position of the second column of bytes
        // this happens when the image's length is not a multiple of 8
        // and so the first pixels need to be saved to a separate byte
        START_COL2 = IMAGE_WIDTH % 8;

        // remembers whether the image's width had to be adjusted
        WIDTH_HAS_BEEN_ADJUSTED = START_COL2 != 0;

        // converts the buffered image to a byte array
        image = toByteImage(bImg);
    }

    // =============================================================
    //                IMAGE CONVERSION TO BYTE ARRAY
    // =============================================================

    /**
     * Creates an optimised byte representation of the image
     * @param bufferedImage original buffered form of the image
     * @return byte representation of the image
     */
    private int[][] toByteImage(BufferedImage bufferedImage) {

        // the image in byte form
        int[][] byteImage = new int[IMAGE_HEIGHT][BYTES_PER_ROW];

        // initialises the image to be made up of the necessary number of bit
        // where one bit represents 8 pixels of the image
        // TODO : add empty rows above, below and to the side of the image

        // fills the image's every row with its representation in byte form
        for (int row = 0; row < IMAGE_HEIGHT; row++) {
            byteImage[row] = fillByteRow(bufferedImage, row, BYTES_PER_ROW);
        }

        // returns the image in byte form
        return byteImage;

    }

    /**
     * Generates a row of bytes representing a row of pixels in the image
     * @param bufferedImage original buffered form of the image
     * @param currentRow y-coordinates of the row of pixels to convert to byte representation
     * @param BITS_PER_ROW number of pits per row of pixels (depending on the width of the image)
     * @return row of pixels in byte form
     */
    private int[] fillByteRow(BufferedImage bufferedImage, int currentRow,
                              final int BITS_PER_ROW) {

        // array the row will be saved to
        int[] bitRow = new int[BITS_PER_ROW];

        // for every byte that will make up the row...
        for (int col = 0; col < BITS_PER_ROW; col++) {

            // region handling the 1st column

            // if the original image does not have a multiple of 8 pixels per row,
            // and we are at the first row
            if ((col == 0) && WIDTH_HAS_BEEN_ADJUSTED) {

                // gets all the pixels which compose that row
                Color[] pixels = getPixelsRange(bufferedImage, currentRow, 0, START_COL2);

                // and adds them to the byte representation of the current row
                bitRow[col] = colorToByte(pixels, col);

                // moves on to the next row
                continue;
            }

            // endregion

            // converts the current column number
            // to its x-coordinates along the image
            int imageColCoordinates = col * 8 - (8-START_COL2);

            // gets the pixels that should be in that column
            Color[] pixels = getPixelsRange(bufferedImage, currentRow, imageColCoordinates, imageColCoordinates+8);

            // and adds them to the byte representation of the current row
            bitRow[col] = colorToByte(pixels, col);
        }

        // returns the byte representation of the row
        return bitRow;
    }

    /**
     * Gets the values of pixels within a certain range of the image
     * @param bufferedImage image from which the pixels are selected
     * @param currentRow y-coordinates of the pixel
     * @param startCol starting x-coordinates of the selection
     * @param endCol end x-coordinates of the selection
     * @return array containing the color of each pixel
     */
    private Color[] getPixelsRange(BufferedImage bufferedImage, int currentRow, int startCol, int endCol) {

        // array that will contain the color of each pixel
        Color[] pixels = new Color[endCol - startCol];

        // for every pixel contained within the specified range...
        for (int col = startCol; col < endCol; col++) {

            // ...gets the color value of that pixel
            pixels[col-startCol] = new Color(bufferedImage.getRGB(col, currentRow));
        }

        // returns the color of each of the pixels within the specified range
        return pixels;
    }

    /**
     * Converts the color value of a set of pixels to its byte representation
     * @param pixels pixels to convert
     * @param pixelColumn byte column the set of pixels is a part of
     * @return array of pixels in byte form
     */
    private int colorToByte(Color[] pixels, int pixelColumn) {

        // array that will contain the byte value of the pixel
        // 0 = white pixel
        // 1 = black pixel
        int rowValue = 0;

        // the number of pixels under consideration
        // this is not necessarily 8 in the case where the image's width
        // is not a multiple of 8 and the first column has to adjusted
        final int NUM_PIXELS = pixels.length;

        // for every pixel...
        for (int col = 0; col < NUM_PIXELS; col++) {
            // ...adds the pixel in bit form to the row
            rowValue += (toBit(pixels[col]) << (NUM_PIXELS-1-col));
        }

        // if there are less than 8 pixels and these pixels are part of the 1st column
        // (i.e. the first column has to be adjusted)
        if ((rowValue < 0x80) && (pixelColumn == 0)) {
            // ...adds a 1 at the start of the byte representation
            // of the row so as not to lose empty pixels
            rowValue |= 0x80;
        }

        // returns the set of pixel in byte form
        return rowValue;
    }

    /**
     * Converts the RGB value of a pixel to a binary value
     * <list>
     *     <li>0 : white pixel</li>
     *     <li>1 : black pixel</li>
     * </list>
     * @param pixelColor pixel's color
     * @return pixel in binary form
     *
     */
    private int toBit(Color pixelColor) {
        // determines whether the specified pixel is black or white
        // black is if luminance < 128
        // white is if luminance >= 128
        return pixelLuminance(pixelColor) < 128 ? 1 : 0;
    }

    /**
     * Computes the luminance value (greyscale value) of a pixel.
     * <p>
     * This method follows the Rec. 601 standard of ITU-R and uses the following
     * formula: {@link #LUMA_COEFFICIENT_RED} * Red +
     * {@link #LUMA_COEFFICIENT_GREEN} * Green + {@link #LUMA_COEFFICIENT_BLUE} *
     * Blue.
     *
     * @param pixelColor the pixel's ARGB values as an int.
     * @return The luminance.
     *
     * @author Jamilla Sam   
     */
    private static int pixelLuminance(Color pixelColor) {
        final int red   = pixelColor.getRed();
        final int green = pixelColor.getGreen();
        final int blue  = pixelColor.getBlue();
        return (int) Math.round(LUMA_COEFFICIENT_RED * red
                                + LUMA_COEFFICIENT_GREEN * green
                                + LUMA_COEFFICIENT_BLUE * blue);
    }

    // =============================================================
    //                        IMAGE DISPLAY
    // =============================================================

    /**
     * Displays the bytes composing the image
     */
    public void displayByteImage() {

        // for every row of bytes composing the image...
        for (int[] bytes : image) {
            // ...and every byte in each row...
            for (int aByte : bytes) {
                // ...converts the byte to a readable format
                System.out.print(formatByte(aByte, true) + " ");
            }

            // creates a space between line
            System.out.println();
        }
    }

    /**
     * Converts a byte to a string and fixes its length to 8
     * @param aByte the byte to format
     * @return string byte of fixed length
     */
    public String formatByte(int aByte, boolean replaceZeros) {

        // the byte in string form
        String stringByte = Integer.toBinaryString(aByte);

        // if the byte's binary form is less than 8 bites long
        // adds the remaining 0 bites to its string representation
        if (aByte < 0x80) {
            stringByte = stringBits.get(stringByte.length()) + stringByte;
        }

        // directly returns the byte otherwise
        return replaceZeros ? stringByte.replace("0", "_") : stringByte;
    }

    // =============================================================
    //                          ACCESSORS
    // =============================================================

    /**
     * Converts a pixel's coordinates in the image to its coordinates
     * in the byte array in case the width has been adjusted
     * @param pixelCol x-coordinates of the pixel
     * @return coordinates of the pixel in the byte array
     * <list>
     *     <li>0: position of the byte</li>
     *     <li>1: position of the pixel in the byte</li>
     * </list>
     */
    private int[] getPixelCoordinates(int pixelCol) {

        // the variable in which the coordinates of the pixel along the byte array will be stored
        int[] pixelColumnCoordinates = new int[2];

        // the variable in which the coordinates of the byte the pixel is in will be store
        int pixelByte = 0;
        // the variable in which the position of the pixel in the byte will be store
        int pixelBytePosition = 0;

        // if the with of the image has had to be adjusted in byte form...
        if (WIDTH_HAS_BEEN_ADJUSTED) {
            // ...takes into account that adjustment
            pixelCol += START_COL2;
        }

        // determines the position of the byte which holds the pixel
        pixelByte = pixelCol % 8;
        // determines the position of the pixel in the byte containing it
        pixelBytePosition = pixelCol - 8 * pixelByte;

        // returns the byte's position and the pixel's position -in that order
        return new int[]{pixelByte, pixelBytePosition};
    }

    private int getPixelFromByte(int aByte, int pixelBytePosition) {

        // extracts the pixel's value from the byte containing it
        return aByte & getBits.get(pixelBytePosition);

    }

    public int getPixel(int pixelCol, int pixelRow) {

        // region SPECIAL CASE : invalid pixel coordinates
        // the pixel's x-coordinate are either inferior to zero or greater than the image's width
        // the pixel's y-coordinate are either inferior to zero or greater than the image's height
        if ((pixelCol < 0 || pixelCol > IMAGE_WIDTH_RANGE) || (pixelRow < 0 || pixelRow > IMAGE_HEIGHT_RANGE)) {

            // throws an error specifying that the pixel's coordinates are invalid
            throw new PixelOutOfBoundError(pixelCol, pixelRow, IMAGE_WIDTH_RANGE, IMAGE_HEIGHT_RANGE);
        }

        // endregion

        // region SPECIAL CASE : image hasn't been generated yet
        if (image == null) {

            // throws an error specifying that the pixel cannot be
            // retrieved since the image hasn't been generated yet
            throw new ImageNotGeneratedError("Impossible to access pixel value" +
                                                " image hasn't been generated yet");
        }

        // endregion

        // gets the pixel's coordinates, taking into account
        // any possible adjustment of the image's width
        int[] pixelCoordinates  = getPixelCoordinates(pixelCol);
        int pixelByteCoordinate = pixelCoordinates[0];  // the x-coordinates of the byte in which the pixel is located
        int pixelBytePosition   = pixelCoordinates[1];  // the position of the pixel in the byte containing it

        // determines the byte in which the pixel is located
        int pixelByte = image[pixelRow][pixelByteCoordinate];

        // extracts the value of the pixel from the byte containing it
        int pixelValue = getPixelFromByte(pixelByte, pixelBytePosition);

        // returns the value of the pixel
        return pixelValue;
    }

    public int getByte(int byteCol, int byteRow) {

        // region SPECIAL CASE : invalid byte coordinates
        // the byte's x-coordinate are either inferior to zero or greater than the number of bytes per image row
        // the byte's y-coordinate are either inferior to zero or greater than the image's height
        if ((byteCol < 0 || byteCol > BYTES_PER_ROW - 1) || (byteRow < 0 || byteRow > IMAGE_HEIGHT_RANGE)) {

            // custom error message
            String errorMessage = String.format("Invalid byte coordinates, valid coordinates are " +
                                                "x:0-%s y:0-%s, " +
                                                "current coordinates : x=%s y=%s",
                                                BYTES_PER_ROW-1, IMAGE_HEIGHT_RANGE, byteCol, byteRow);

            // throws an error specifying that byte's coordinates are invalid
            throw new PixelOutOfBoundError(errorMessage);
        }

        // endregion

        // region SPECIAL CASE : image hasn't been generated yet
        if (image == null) {

            // throws an error specifying that the pixel cannot be
            // retrieved since the image hasn't been generated yet
            throw new ImageNotGeneratedError("Impossible to access pixel value" +
                    " image hasn't been generated yet");
        }

        // endregion

        // returns the byte at the specified coordinates
        return image[byteRow][byteCol];
    }

    public void setPixel(int pixelCol, int pixelRow) {

    }

    public void setByte(int byteCol, int byteRow) {

    }

    // =============================================================
    //                      FIELD INITIALIZERS
    // =============================================================

    /**
     * Generates a HasMap of Integers with the position of a pixel in a byte as the key<br>
     *
     * Helps to access a pixel within a byte by providing the integer value needed to
     * retrieve the pixel through a bitwise and operation
     * @return HashMap linking pixel position to the integer needed to extract it's value
     */
    private HashMap<Integer, Integer> generateGetBits() {

        // HashMap to which the pixel position and the
        // value need to retrieve that bit are saved
        HashMap<Integer, Integer> getBitsBuilder = new HashMap<>();

        // associates each possible position of a pixel to the number
        // whose binary form allows to retrieve the pixel's information
        getBitsBuilder.put(0, 0x80);
        getBitsBuilder.put(1, 0x40);
        getBitsBuilder.put(2, 0x20);
        getBitsBuilder.put(3, 0x10);
        getBitsBuilder.put(4, 0x8);
        getBitsBuilder.put(5, 0x4);
        getBitsBuilder.put(6, 0x2);
        getBitsBuilder.put(7, 0x1);

        // returns the filled HashMap
        return getBitsBuilder;
    }

    /**
     * Generates a HashMap of strings with the length of a byte as a key <br>
     *
     * Helps to determine how many 0s have to be added at the start of the byte to fix its length to 8
     * @return HashMap linking byte length to string
     */
    private HashMap<Integer, String> generateStringBits() {

        // HashMap to which the byte length and string pairs are saved
        HashMap<Integer, String> stringBitBuilder = new HashMap<>();

        // associates each possible length of a byte (apart from 8)
        // to the number of 0s needed to fix the length of that byte to 8
        stringBitBuilder.put(1, "0000000" );
        stringBitBuilder.put(2, "000000"  );
        stringBitBuilder.put(3, "00000"   );
        stringBitBuilder.put(4, "0000"    );
        stringBitBuilder.put(5, "000"     );
        stringBitBuilder.put(6, "00"      );
        stringBitBuilder.put(7, "0"       );

        // returns the filled HashMap
        return stringBitBuilder;
    }

    // =============================================================
    //                           FIELDS
    // =============================================================

    /**
     * Whether the width of the image has had to be adjusted
     * by adding an extra byte at the start of each row
     */
    final boolean WIDTH_HAS_BEEN_ADJUSTED;

    /**
     * The image under binary form, encoded into bytes
     */
    private int[][] image;
    /**
     * The number of bits under string form needed to fix the length of a byte to 8 bits
     */
    private HashMap<Integer, String> stringBits = generateStringBits();

    private HashMap<Integer, Integer> getBits = generateGetBits();

    /**
     * Height (in pixels) of the image
     */
    public final int IMAGE_HEIGHT;
    /**
     * Width (in pixels) of the image
     */
    public final int IMAGE_WIDTH;
    /**
     * Maximum row index in the image BufferedImage and byte array form
     */
    public final int IMAGE_HEIGHT_RANGE;
    /**
     * Maximum column index in the image's BufferedImage form
     */
    public final int IMAGE_WIDTH_RANGE;

    /**
     * the number of bytes contained in a row of pixels
     */
    public final int BYTES_PER_ROW;
    /**
     * Starting index in the BufferedImage of the pixels after the first byte in the byte form of the image
     */
    private final int START_COL2;

    /**
     * The luma coefficient for red from Rec. 601 standard of ITU-R. This
     * coefficient is used to calculate a pixel's luminance from its RGB components
     */
    private final static double LUMA_COEFFICIENT_RED = 0.299;

    /**
     * The luma coefficient for green from Rec. 601 standard of ITU-R. This
     * coefficient is used to calculate a pixel's luminance from its RGB components
     */
    private final static double LUMA_COEFFICIENT_GREEN = 0.587;

    /**
     * The luma coefficient for blue from Rec. 601 standard of ITU-R. This
     * coefficient is used to calculate a pixel's luminance from its RGB components
     */
    private final static double LUMA_COEFFICIENT_BLUE = 0.114;

}
