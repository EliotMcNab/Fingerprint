package image;

/**
 * Used to warn that a specific action cannot be executed while the image hasn't been generated
 */
    public class ImageNotGeneratedError extends RuntimeException {

    /**
     * Throws a new ImageNotGeneratedError with a default message <br>
     * <strong>default message : </strong> Image hasn't been generated yet
     */
    public ImageNotGeneratedError() {

        // calls the super constructor with a default error message
        super("Image hasn't been generated yet");
    }

    /**
     * Throws a new ImageNotGeneratedError with a custom errorMessage
     * @param errorMessage custom error message
     */
    public ImageNotGeneratedError(String errorMessage) {

        // calls the super constructor with a custom error message
        super(errorMessage);
    }

}
