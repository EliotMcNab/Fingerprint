package image;

/**
 * Warns that a pixel's value in an image cannot be retrieved because its coordinates are invalid
 */
public class PixelOutOfBoundError extends RuntimeException {

    /**
     * Throws a new PixelOutOfBoundError with a default message <br>
     * <strong>default message : </strong> Invalid pixel coordinates
     */
    public PixelOutOfBoundError() {

        // calls the super constructor with a default error message
        super("Invalid pixel coordinates");
    }

    /**
     * Throws a new PixelOutOfBoundsError with a custom errorMessage
     * @param errorMessage custom error message
     */
    public PixelOutOfBoundError(String errorMessage) {

        // calls the super constructor with a custom error message
        super(errorMessage);
    }

    /**
     * Throws a new PixelOutOfBoundsError specifying the coordinates
     * of the pixel at which the error occurred and what is the valid
     * range of values for these coordinates
     * @param pixelCol  x-coordinates of the pixel
     * @param pixelRow  y-coordinates of the pixel
     * @param maxCol    maximum x-coordinates the pixel can have
     * @param maxRow    maximum y-coordinates the pixel can have
     */
    public PixelOutOfBoundError(int pixelCol, int pixelRow, int maxCol, int maxRow) {

        // calls the super constructor by specifying the
        // coordinates of the pixel at which the error occurred
        super(
                String.format("Invalid pixel coordinates, valid coordinates are x:0-%s y:0-%s, " +
                "current coordinates: x=%s y=%s", maxCol, maxRow, pixelCol, pixelRow)
        );
    }
}
