import image.Image;

public class Main {

    public static void main(String[] args) {

        Image test = new Image("src/1_1.png");
        test.displayByteImage();

    }
}
